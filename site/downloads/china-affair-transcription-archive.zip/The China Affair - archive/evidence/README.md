# Evidence

Page images that settled a specific question. Nothing here is decorative — each
file is the thing that was actually looked at before a decision was made, and
each is referenced from `reports/corrections.md` or `reports/verification.md`.

File names use **scan page numbers** (position in the PDF). The typist's own
hand-written folio numbers, at the foot of each page, run three lower — so scan
page 230 carries the folio "227".

## faint-pages/

Full scans of the pages where OCR confidence fell below 92%. These are carbon
copies with a worn ribbon; Tesseract dropped whole lines on several of them, so
pages 150–156 were read off these images and typed out by hand. The
transcriptions are in `../data/overrides.json`.

| File | Mean OCR confidence |
|---|---|
| `scan-p150-retranscribed.png` | 89.6% |
| `scan-p151-retranscribed.png` | 87.9% |
| `scan-p152-retranscribed.png` | 91.1% |
| `scan-p153-retranscribed.png` | 90.4% |
| `scan-p154-retranscribed.png` | 84.4% |
| `scan-p155-retranscribed.png` | 85.5% |
| `scan-p156-retranscribed.png` | 86.6% |
| `scan-p049-faint-final-line.png` | 91.1% — only the last line failed, so the page was corrected rather than retyped |

## decisions/

### How the page layout was read

| File | What it shows |
|---|---|
| `p001-title-page-scanned-sideways.png` | The title page went through the scanner rotated 90°, which is why its text had to be read separately rather than parsed with the rest. |
| `p008-footnote-separator-is-short.png` | The footnote rule is only about 250 px wide. The first pass looked for rules ≥ 400 px and missed pages like this one. |
| `p019-rule-touches-first-note-line.png` | The rule sits so close to the first note line that their bounding boxes overlap — this is why splitting strictly below the rule leaked footnote text into the body, and why the split needed a tolerance. |
| `p154-footnote-block-single-spaced.png` | Footnotes are single-spaced beneath a rule, while the body is double-spaced. |
| `p060-paragraph-indent-is-276px.png` | A normal paragraph indent on this page is 276 px, against roughly 150 px elsewhere. Indent depth varies by page, which is why a fixed threshold could not separate paragraphs from quotations. |
| `p121-telegram-indented-but-double-spaced.png` | A quoted telegram: deeply indented but *double*-spaced, which ruled out line spacing as the signal for quoted matter. |
| `p052-verse-centred-single-spaced.png` | The German children's rhyme — centred and single-spaced, so it keeps its line breaks rather than being reflowed. |
| `p080-continued-is-a-typist-marker.png` | A short page ending with a centred "continued". A production note from the typist, not manuscript text, so it is dropped. |
| `p052-running-header-sits-low.png` | The one running header that sits below the usual band, which is how it slipped into the body text until the header rule was matched by shape rather than position. |

### Umlauts, checked name by name

The scanner turned ö/ü/ä into `&`, `é`, `S`, `8` or `d`, often differently on
different pages for the same name. Each of these was read off the page before
the correction was made.

| File | Restores |
|---|---|
| `p027-Goppingen-and-Schutte.png` | Göppingen |
| `p029-Schutte-Lanz.png` | Schütte-Lanz, and Dr. Schütte |
| `p105-Bodecker.png` | Lt. Bödecker |
| `p134-Goring-and-Konigin.png` | Göring, and Königin Augustastrasse |
| `p225-Brocker.png` | Bröcker — the crew list that settled this spelling |
| `p060-Spahkorb.png` | Spähkorb, the observation gondola |
| `p183-Gobel-Afrika-zu-unseren-Fussen.png` | Göbel, and his book *Afrika zu unseren Füssen* |
| `p168-Der-Feind-hoert-mit.png` | "Der Feind hört mit!" |

### Passages read off the page

Faint spans where several words were garbled together, so the reading was taken
from the image rather than repaired token by token.

| File | Recovered reading |
|---|---|
| `p049-required-a-ship-of-1765500-displacement.png` | "…would require a ship of 1,765,500 displacement" |
| `p124-freezing-temperatures.png` | "in the freezing temperatures" (scanned as `pErErnTER`) |
| `p144-spare-elevator-helmsman.png` | "as a spare elevator helmsman" |
| `p146-necessary-parations.png` | "allowing for necessary parations" — and note *parations* is the author's own slip, so it stands |
| `p158-than-steal-information.png` | "A spy does more than steal information." |
| `p191-at-a-low-altitude.png` | "duck under it at a low altitude" |
| `p228-already-left-Mangelsdorf.png` | "already left. Mangelsdorf did not learn…" |
| `p232-benefit-of-what-he-had-learned.png` | "giving it the benefit of what he had learned…" |
| `p234-29-dead-and-Naples-curiously.png` | "leaving 29 dead and fifty injured" (this crop is from scan page 235) |
| `p234-Naples-ran-curiously.png` | "the people of Naples ran curiously to…" |

### Readings checked and deliberately left alone

| File | What it settles |
|---|---|
| `p025-mililtary-is-typed-that-way.png` | "mililtary" is in the typescript. Not corrected. |
| `p150-degress-is-typed-that-way.png` | "43 degress F." is typed that way, with *degrees* spelled correctly on the next line. Not corrected. |
| `p253-author-omitted-the-word-put.png` | "seems to have been into circulation" — *put* is genuinely absent from the page. An authorial slip, not a scanning loss. |
| `p166-full-stop-read-as-comma.png` | Here the opposite: the page reads "code books." and the scanner read a comma. Corrected, because it is a misreading rather than the author's punctuation. |
| `p190-sky-was-solidly.png` + `p191-overcast-completes-the-sentence.png` | The sentence "…the sky was solidly overcast." runs across a page break. The one-word line "overcast." was faint enough that the noise filter was discarding it, silently truncating the sentence. Read together, these two show why the filter had to be changed to never drop a plausible word. |
| `p230-struck-through-word.png` | The single editorial judgment in the document: *doing* struck through by hand, with a correction above it too faint to read. Set as "did". |

---

Two file names carry wording from an earlier pass and are slightly generous:
`p027-Goppingen-and-Schutte.png` shows only Göppingen (Schütte-Lanz is on scan
page 29, filed separately), and `p234-29-dead-and-Naples-curiously.png` is
cropped from scan page 235 and shows only the "29 dead" line. The workspace does
not permit renaming files here, so the names stand and this note corrects them.
