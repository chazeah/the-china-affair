# Pipeline statistics

## Source

| | |
|---|---|
| File | `The China Affair manuscript (scanned 7-26).pdf` |
| Pages | 267 |
| Size | 52.6 MB |
| Text layer | none — pure raster scan |
| Page size | 792 × 612 pt (US Letter, landscape-flagged) |
| Producer | EFI Cyclone |

## OCR

| | |
|---|---|
| Engine | Tesseract 4.1.1, `--psm 3`, English |
| Render | `pdftoppm -gray -r 300` (2550 × 3301 px/page) |
| Output | TSV with per-word bounding boxes and confidence |
| Lines recognised | 7,740 |
| Median line confidence | 95.2% |
| Pages ≥ 90% mean body confidence | 261 / 266 |
| Pages 80–90% | 5 |
| Pages < 80% | 0 |

PSM 3 was chosen over 4 and 6 after comparing all three on sample pages: it
preserved the blank lines between paragraphs and avoided a spurious leading
character that PSM 6 introduced.

## Reconstructed structure

| Block type | Count |
|---|---|
| Body paragraphs | 522 |
| Chapter headings | 15 |
| Footnotes | 31 |
| Block quotations | 6 |
| Verse / telegram blocks | 5 |
| **Total words** | **67,914** |

Footnote separator rules detected from pixel data on 30 pages.

## Output

| | |
|---|---|
| Format | .docx, US Letter, 1"/1.25" margins |
| Type | 12 pt Times New Roman, double-spaced, 0.5" first-line indent |
| Length | 227 pages |
| Footnotes | 31, as real Word footnotes anchored at the author's asterisks |
| Validation | passed structural XSD checks |

