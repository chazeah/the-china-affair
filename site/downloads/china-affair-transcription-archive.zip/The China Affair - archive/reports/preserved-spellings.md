# Preserved spellings

The brief was to fix scanning artifacts and leave the author's wording, spelling
and punctuation untouched. That distinction is the most consequential judgment in
the whole job, so this file records where the line was drawn and why.

## How the two were told apart

OCR errors and typing errors fail in different ways, and the difference is
usually legible:

**Scanning errors are visual.** Tesseract confuses letters that *look* alike at
300 dpi on a worn typewriter ribbon — `n`/`h`, `l`/`1`, `i`/`l`, `v`/`y`,
`c`/`e`, `rn`/`m`, `q`/`g`. So `tne` for *the*, `nad` for *had*, `inguiry` for
*inquiry*, `3lst` for *31st*. These produce strings no typist would ever
produce, and they appear once or twice rather than consistently.

**Typing errors are phonetic or mechanical** — a doubled letter, a dropped
letter, a transposition, a misremembered spelling. So `occured`, `embarassment`,
`accomodated`. These recur, because a writer who spells a word one way tends to
keep spelling it that way.

Where the two tests disagreed, or where a reading could plausibly be either, the
page image was opened and the question settled by looking. Anything still
ambiguous after that was left as scanned, on the principle that an unwanted
authorial quirk is recoverable later but an invented word is not.

## Consistent authorial spellings

Each of these appears in the typescript as written, most of them more than once:

| Spelling | Times | Standard form |
|---|---|---|
| `occured` | 7 | occurred |
| `socalled` | 3 | so-called |
| `longitudenal` | 4 | longitudinal |
| `anonimity` | 3 | anonymity |
| `darkeness` | 3 | darkness |
| `embarassment` | 3 | embarrassment |
| `dilemna` | 2 | dilemma |
| `disasterous` | 2 | disastrous |
| `reconaissance` | 2 | reconnaissance |
| `selfassurance` | 2 | self-assurance |
| `accomodated`, `accomodations` | 1 each | accommodated / accommodations |
| `aeronatical` | 1 | aeronautical |
| `aggrevated` | 1 | aggravated |
| `appearence` | 1 | appearance |
| `assesment` | 1 | assessment |
| `assidiously` | 1 | assiduously |
| `battallions` | 1 | battalions |
| `boyancy` | 1 | buoyancy |
| `brakish` | 1 | brackish |
| `capablities` | 1 | capabilities |
| `caried` | 1 | carried |
| `combattants` | 1 | combatants |
| `concesssion` | 1 | concession |
| `condtions` | 1 | conditions |
| `consitute` | 1 | constitute |
| `envisionaged` | 1 | envisaged |
| `Penninsula` | 1 | Peninsula |
| `propellors` | 4 | propellers |
| `Portugese` | 12 | Portuguese |

## One-off typing slips, kept

Verified against the page image in each case — the typescript reads this way:

| Page (scan) | Reading | Standard form |
|---|---|---|
| 25 | `mililtary airships` | military |
| 150 | `43 degress F.` | degrees — and *degrees* is spelled correctly on the very next line |
| 155 | `broke through the clounds` | clouds |
| 155 | `and alkso from the altimetric record` | also |
| 187 | `the Bulgartian recruits` | Bulgarian — spelled correctly in the same sentence |
| 146 | `allowing for necessary parations` | preparations |
| 253 | `seems to have been into circulation` | *put* is simply missing |
| 166 | `Wichester grand jury` | Winchester |
| — | `Dartmout and others` | Dartmouth |
| — | `Shorly after May 17` | Shortly |
| — | `snow-capped Kililmanjaro` | Kilimanjaro |
| — | `Mirable dictu` | Mirabile dictu |
| — | `the House of Hohenzoller` | Hohenzollern |
| — | `An Imperial Commenddation` | Commendation |
| — | `Straser sent a telegraph` | Strasser — correct in dozens of other places |
| — | `Feburary 1919` | February |
| — | `Admiral Tripitz` | Tirpitz |
| — | `a station at Kamina in Germanland` | German land |
| — | `for the Mediterraenean area` | Mediterranean |
| — | `Commander Mangelsdorff` | Mangelsdorf — the author uses both |
| — | `the airship portection` | protection |
| — | `gradully tiring`, `a surpise attack`, `it could be troubleseome` | gradually / surprise / troublesome |
| — | `the sailors weren restless` | were |
| — | `interrested in whether` | interested |
| — | `the avalable information`, `radion triangulation` | available / radio |
| — | `explosion of gas, ammuntion and fuel` | ammunition |
| — | `as Sir Alfred had descibed it` | described |
| — | `To guard minsweepers` | minesweepers |
| — | `had probably suceeded` | succeeded |
| — | `Weather and cicumstances` | circumstances |
| — | `lay wainting in its hangar` | waiting |
| — | `whatever suppplies it contained` | supplies |
| — | `ropute provided for in the original plan` | route |
| — | `With alighter ship` | a lighter |
| — | `enough metereological information` | meteorological — he also writes `meterological` |
| — | `a factually corect account of the voyage` | correct |
| — | `may have acounted for this` | accounted |
| — | `unable to develope them` | develop |
| — | `firsat at the destruction` | first |
| — | `across terrestial obstacles` | terrestrial |
| — | `parabaloid shaped` | paraboloid |

That list is longer than the corrections log's letter-confusion section, and
deliberately so. It is the clearest evidence that the transcription is faithful:
after the scanning errors were removed, what remained was a writer's own typing.

## British spellings

Left as typed rather than Americanised: `criticised`, `emphasise`, `cyphers`,
and `judgement` — though the author is inconsistent here, using `judgment`
14 times against `judgement` 3 times. Both forms are his, so both stand.

## The author's compound nouns

He habitually closes up compounds that most writers hyphenate or space. These
are a stylistic habit, not errors, and they are consistent:

`airforce` · `airforces` · `airdefense` · `airwar` · `airmasses` · `airlayers` ·
`airlegs` · `airstrength` · `airshipmen` · `groundcrew` · `bombload` ·
`machinegun` · `machineguns` · `rudderman` · `wingracks` · `teaparty` ·
`duraluminum`

## German and French left in place

`von` · `der` · `des` · `Jetzt erst recht!` · `Der Feind hört mit!` ·
`vertretbare Schuld` · `Faust Natur` · `Hochwohlgeboren` · `Spähkorb` ·
`Reichsmarineamt` · `Admiralstab` · `Aktiengesellschaft` ·
`Afrika zu unseren Füssen` · `Zeppelin flieg.` · `Hilf uns im Krieg.` ·
`Quai d'Orsay` · `Deuxième Bureau` · `Pour le Mérite` · `lingua franca` ·
`askaris` · `elan`

Umlauts *were* restored in these, because the scanner had mangled the diacritic
itself into `&`, `é`, `S` or `8` — that is a scanning failure, not a spelling
choice. See section 1 of `corrections.md`.

## What remains uncorrected

About 0.46% of words in the finished document are not in a standard English
dictionary. A large share is the material above — authorial spellings, German,
and proper nouns from the manuscript's cast of several hundred people, ships and
places. The remainder is a thin tail of single-occurrence OCR slips on faint
lines that were judged not worth the risk of a guess. If you want to work
through them, `pipeline/tools/review_residue.py` regenerates the review sheets
that pair each remaining oddity with a crop of the line it came from.
